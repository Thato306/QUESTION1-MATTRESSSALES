package com.mattress.sales;

/**
 * Responsible only for printing the report data (Q.1.3).
 */
public class PrintProduct {

    private IProduct product;

    public PrintProduct(IProduct product) {
        this.product = product;
    }

    public void printHeader() {
        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println();
        System.out.println("**********************************************");
    }

    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void printAverageProductSales() {
        double average = product.GetAverageProductSold();

        // Show 17 instead of 17.0 when the average is a whole number (like the sample)
        if (average == Math.floor(average)) {
            System.out.println("AVERAGE PRODUCT SALES: " + (int) average);
        } else {
            System.out.println("AVERAGE PRODUCT SALES: " + String.format(java.util.Locale.US, "%.2f", average));
        }
    }

    public void printMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}
